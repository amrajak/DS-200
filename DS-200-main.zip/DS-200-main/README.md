# DS-200
Research Methods (credit:1)- Assignment
<p>
<a href="https://data.gov.in/catalog/district-rainfall-normal-mm-monthly-seasonal-and-annual-data-period-1951-2000?filters%5Bfield_catalog_reference%5D=87155&format=json&offset=0&limit=6&sort%5Bcreated%5D=desc" target="_blank"> Data used</a> 
</p>

## SCATTER Plot
![stack Overflow](https://raw.githubusercontent.com/amrajak/DS-200/main/plot/scatter.png)


## LINE plot
![stack Overflow](https://raw.githubusercontent.com/amrajak/DS-200/main/plot/line.png)

## BOX Plot
![stack Overflow](https://raw.githubusercontent.com/amrajak/DS-200/main/plot/box1.png)
![stack Overflow](https://raw.githubusercontent.com/amrajak/DS-200/main/plot/box2.png)

